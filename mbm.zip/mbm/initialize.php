<?php
/**
 * Initialize the fundamental things we need, defined as:
 * - Boot error handling (ie, errors before ZF starts handling, or those outside ZF scope)
 * - Autoloading
 *
 * Returns the constant we expect to be defined boolean true if a clean exit is made.
 *
 * @see http://me.veekun.com/blog/2012/04/09/php-a-fractal-of-bad-design/
 */

// *** BOOT ERROR HANDLING ***
// our worst-case-scenario handler, called only when something goes really wrong,
// the application didn't handle it, and a developer definitely needs to get involved
// this will not be called when "RUN_FINISHED" is not defined true
function whoops($code, $message, $trace) {
    if (defined('RUN_FINISHED') && constant('RUN_FINISHED')) {
        exit(0);
    }
    define('RUN_FINISHED', true);

    echo "<h1>Whoops!</h1>\n<p>Something went horribly wrong.</p>\n<p><b>$message</b></p>\n";
    if (0 < count($trace)) {
        echo '<ol><li>' . implode('</li><li>', array_map('_initialize_helper_frame', $trace)) . '</li></ol>';
    }

    exit(1);
}

// connect it to all the ways PHP crashes/exits
set_exception_handler(function ($ex) {
    whoops($ex->getCode(), $ex->getMessage(), $ex->getTrace());
});
set_error_handler(function ($code, $message, $file, $line) { whoops($code, $message, debug_backtrace()); });
assert_options(ASSERT_CALLBACK, function ($code, $message, $file, $line) { whoops($code, $message, debug_backtrace()); });
register_shutdown_function(function () {
    $error = error_get_last();
    if (null === $error) {
        $code    = null;
        $message = 'Application did not end cleanly. Probably a die() or exit()';
        $trace   = array ();
    } else {
        $code    = $error['type'];
        $message = $error['message'];
        $trace   = array (array ('file' => $error['file'], 'line' => $error['line']));
    }
    whoops($code, $message, $trace);
});


// *** AUTO-LOADING ***
// attach to composer, whose responsible for pulling in our dependencies
$loader = include('vendor/autoload.php');

// add zend to the loader
if (is_callable($loader, 'add')) {
    $loader->add('Zend', 'vendor/zendframework/zendframework/library/');
}

return 'RUN_FINISHED';

// HELPER
function _initialize_helper_frame($f) {
    $signature = (isset($f['args']) ? implode(', ', array_map(function ($x) {
        $t = gettype($x);
        return ('object' === $t ? get_class($x) : $t);
    }, $f['args'])) : '');

    if (isset($f['class']) && isset($f['function']) && isset($f['type'])) {
        $frame = "{$f['class']}{$f['type']}{$f['function']}($signature)";
    } else if (isset($f['function'])) {
        if (
            isset($f['args'][0]) &&
            in_array($f['function'], array ('include', 'include_once', 'require', 'require_once'))
        ) {
            $frame = "{$f['function']}({$f['args'][0]})}";
        } else {
            $frame = "{$f['function']}($signature)";
        }
    } else {
        $frame = print_r($f, true);
    }
    $frame = "<b>$frame</b><br />";
    if (isset($f['file']) && isset($f['line'])) {
        $frame .= "{$f['file']}:{$f['line']}<br />";
    }
    $frame .= "<br />";

    return $frame;
}
?>
