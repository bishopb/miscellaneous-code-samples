<?php
namespace Core\Helper;

use Zend\View\Helper\AbstractHelper;

class Classes extends AbstractHelper {
    /*
    public function __invoke() {
        return $this;
    }
    */
    
    public function add($classes) {
        if (! is_array($classes)) {
            $classes = array ($classes);
        }

        foreach ($classes as $class) {
            if (is_string($class)) {
                $this->classes[$class] = $class;
            } else {
                throw new Zend_Exception('class must be a string');
            }
        }

        return $this;
    }
    
    public function remove($classes) {
        if (! is_array($classes)) {
            $classes = array ($classes);
        }

        foreach ($classes as $class) {
            unset($this->classes[$class]);
        }

        return $this;
    }

    public function set($classes) {
        $this->classes = array ();
        return $this->add($classes);
    }
    
    public function toArray() {
        return $this->classes;
    }

    public function toString() {
        return implode(' ', $this->classes);
    }

    public function __toString() {
        return $this->toString();
    }

    /* protected API */
    protected $classes = array ();
}

?>
