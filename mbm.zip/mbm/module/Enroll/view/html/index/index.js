require(
    [
        'dojo/_base/declare', 'dojo/_base/lang', 'dojo/ready', 'dojo/parser', 'dojo/dnd/Source',
        'dojo/query', 'dojo/NodeList-traverse', 'dojo/topic', 'dojo/dom-attr',
        'dojo/store/Memory', 'dojo/store/Observable',
        'dojox/validate/web',
        'dojo/aspect', 'dijit/Dialog',
        'dojo/currency', 'dojo/html', 'dojo/when',
        'dgrid/GridFromHtml', 'dgrid/OnDemandList',
        'dojo/io-query', 'dijit/registry', 'dojo/on', 'dojo/date/locale',
        'dojo/dom-construct', 'dojo/_base/array', 'dojo/string', 'dojo/dom-class',
        'dojo/request/xhr', 'dojo/_base/event'
    ],
    function (
        declare, Lang, ready, Parser, Source,
        query, _nlt, Topic, DomAttr,
        Memory, Observable,
        _web,
        Aspect, Dialog,
        Currency, Html, when,
        GridFromHtml, OnDemandList,
        IOQuery, Registry, On, Locale,
        DomConstruct, DjArray, DjString, DomClass,
        xhr, Event
    ) {
        var moduleUrl = document.URL.substr(0, document.URL.lastIndexOf('/'));

        var ScoutsDrop = declare(Source, {
            // dropping in, remove from registration cart
            onDropExternal:function (source, nodes, copy) {
                this.inherited(arguments);
                nodes.forEach(Lang.hitch(this, function (node) {
                    this.registration.remove(
                        this.getItem(node.id).data
                    );
                }));

                this.registration.refresh();
            }
        });
        var BadgeDrop = declare(Source, {
            onDropExternal:function (source, nodes, copy) {
                // Note:this order is important!
                // process the drop on me (which manipulates the source argument)
                this.inherited(arguments);

                // reflect (now I am the source, which hasn't been processed yet)
                this.proxyTo.onDropExternal(this, nodes, copy);

                // delete from me
                this.selectAll().deleteSelectedNodes();
            }
        });
        var RegistrantsDrop = declare(Source, {
            // dropping in, add to registration cart
            onDropExternal:function (source, nodes, copy) {
                this.inherited(arguments);
                nodes.forEach(Lang.hitch(this, function (node) {
                    this.registration.put({
                        name:this.getItem(node.id).data,
                        badge:(source.badge ? source.badge : this.badge),
                        price:(source.price ? source.price : this.price)
                    });
                }));

                this.registration.refresh();
            }
        });

        function priceFmt(price) {
            return Currency.format(price, {currency:'USD'})
        };

        window.gridType = declare([GridFromHtml, OnDemandList]);
        window.gridType.priceFmt = function (price) {
            return priceFmt(price);
        };

        // for loading and saving a registration
        function load() {
            var uri = window.location.href;
            var qstr = uri.substring(uri.indexOf('?') + 1, uri.length);
            if (qstr != uri) {
                var qobj = IOQuery.queryToObject(qstr);
                for (var id in qobj) {
                    switch (id) {
                    case 'registrations':
                        // update badge drops and registration cart
                        var registrations = JSON.parse(qobj['registrations']);
                        for (var i = 0; i < registrations.length; i++) {
                            // add to cart
                            cart.get('store').add(registrations[i]);

                            // add to right drop
                            var badge = registrations[i].badge;
                            window.badgesDrop[badge].insertNodes(
                                false,
                                [ registrations[i].name ]
                            );
                        }

                        // refresh the total
                        cart.get('store').refresh();
                        break;

                    default:
                        var widget = Registry.byId(id);
                        if (widget) {
                            widget.set('value', qobj[id]);
                        }
                        break;
                    }
                }

                return true;
            } else {
                return false;
            }
        };

        function save() {
            var uri = window.location.href;
            var base = uri.substring(0, uri.indexOf('?'));
            var qstr = IOQuery.objectToQuery(window.saveObject());
            return base + '?' + qstr;
        };

        window.saveObject = function () {
            return {
                "troop-number":Registry.byId('troop-number').get('value'),
                "troop-council":Registry.byId('troop-council').get('value'),
                "contact-name":Registry.byId('contact-name').get('value'),
                "contact-email":Registry.byId('contact-email').get('value'),
                "scouts-names":query('#scouts-list li').map(function (li) { // similar to ul2ta
                    return li.innerHTML;
                }).join('\n'),
                "registrations":JSON.stringify(cart.get('store').data),
                "card-type":Registry.byId('card-type').get('value'),
                "card-name":Registry.byId('card-name').get('value'),
                "card-expMth":Registry.byId('card-expMth').get('value'),
                "card-expYr":Registry.byId('card-expYr').get('value'),
                "card-billingAddr1":Registry.byId('card-billingAddr1').get('value'),
                "card-billingAddr2":Registry.byId('card-billingAddr2').get('value'),
                "card-city":Registry.byId('card-city').get('value'),
                "card-state":Registry.byId('card-state').get('value'),
                "card-zip":Registry.byId('card-zip').get('value')
            };
        };

        function unique(names) {
            var seen = {};
            for (var i = 0; i < names.length; i++) {
                var name = names[i];
                if (name in seen) {
                    names[i] = name + ' #' + seen[name];
                    seen[name]++;
                } else {
                    seen[name] = 1;
                }
            }

            return names;
        };

        function ta2ul() {
            // empty the ul
            DomConstruct.empty('scouts-list');

            // split the names into an array of unique non-blanks
            var names = unique(
                DjArray.filter(
                    scouts_ta.get('value').split(/\r?\n/g),
                    function (el) {
                        return 0 < DjString.trim(el).length ? true : false;
                    }
                )
            );

            // add to the ul
            for (var i = 0; i < names.length; i++) {
                DomConstruct.place(
                    '<li class="name dojoDndItem">' + names[i] + '</li>',
                    'scouts-list',
                    'last'
                );
            }

            // sync dnd with changes
            window.scoutsDrop.sync();
        };

        function ul2ta() {
            // get the li and build the ta value
            var names = [];
            query('#scouts-list li').forEach(function (li) {
                names.push(li.innerHTML);
            });

            // set the value
            scouts_ta.set('value', names.join('\n'));
        };

        // when the wizard is done, go to the real app
        window.wizardDone = false;
        function go() {
            // refresh seats periodically
            setInterval(seatCheck, 5000);
        };
        function seatCheck() {
            // get seat count from database
            xhr(moduleUrl + '/seats', {handleAs:'json'}).then(function (seats) {
                // get the registrations and subtract them from the seats and update the display
                var registrations = cart.get('store').data;
                for (var badge in seats) {
                    var count = seats[badge];

                    // update seat initial count
                    var cell = findBadgeCell(badge);
                    if (cell) {
                        var span = query('.seats', cell)[0];
                        DomAttr.set(span, 'data-initial', count);

                        // subtract registrations and update seat display
                        for (var i = 0; i < registrations.length; i++) {
                            var registration = registrations[i];
                            if (registration.badge == badge) {
                                count--;
                            }
                        }
                        updateSeats(cell, span, count);
                    }
                }
            });
        };

        function findBadgeCell(target) {
            var match = null;
            query('#badges .badge').forEach(function (badge) {
                var title = query(badge).children('h1')[0];
                if (title.innerHTML == target) {
                    match = badge;
                }
            });

            return match;
        };

        function updateSeats(badge, seats, count) {
            seats.innerHTML = count;
            DomClass[count < 0 ? 'add' : 'remove'](badge, 'full');
        };

        window.buy = function () {
            ordering.show();

            // base save object, plus card number and cvv, minus non-card stuff, plus price
            var data = window.saveObject();
            data['card-number'] = Registry.byId('card-number').get('value');
            data['card-cvv']    = Registry.byId('card-cvv').get('value');

            // post it
            var yikes = 'Server error. Try again in a few minutes. If it recurs, use the Help! button.';
            return xhr.post(
                moduleUrl + '/buy',
                {
                    handleAs:'json',
                    data:data
                }
            ).then(function (result) {
                if (result.success) {
                    query('#receipt-number')[0].innerHTML = result.receipt;
                    query('#email-for-confirmation')[0].innerHTML = data['contact-email'];

                    ordering.hide();
                    success.show();
                } else if (result.reason) {
                    query('#failure-message')[0].innerHTML = result.reason;

                    ordering.hide();
                    failure.show();
                } else {
                    query('#failure-message')[0].innerHTML = yikes;
                }
            }, function (err) {
                query('#failure-message')[0].innerHTML = yikes;
            });
        };

        window.print_receipt = function (ev) {
            Event.stop(ev);

            var receipt = query('#success .dijitDialogPaneContentArea')[0];
            var printer = query('#printer')[0];
            var iframe = (
                printer.contentWindow ?
                printer.contentWindow :
                (printer.contentDocument.document ? printer.contentDocument.document : printer.contentDocument)
            );
            iframe.document.open();
            iframe.document.write(receipt.innerHTML);
            iframe.document.close();
            iframe.print();
        };

        window.startover = function () {
            window.location.href = moduleUrl + '/register';
        };

        // when the page is ready, manipulate the dom
        ready(function () {
            // create our layout widgets
            Parser.parse().then(function () {
                // create a registration store and connect it into the cart
                var registration = new Observable(new Memory({data:[], idProperty:'name'}));
                cart.set('store', registration);
                registration.refresh = function () { // can't use observe, because sometimes we're just changing a row
                    var total = 0;
                    when(this.query({}), function (items) {
                        // sum up the cart total and count seats
                        var counts = {};
                        var i = 0;
                        while (i < items.length) {
                            total += parseFloat(items[i].price);
                            if (items[i].badge in counts) {
                                counts[items[i].badge]++;
                            } else {
                                counts[items[i].badge] = 1;
                            }
                            i++;
                        }

                        // update the total wherever we want it
                        query('.total').forEach(function (el) {
                            el.innerHTML = priceFmt(total);
                        });

                        // update the seat counts
                        query('#badges .badge').forEach(function (badge) {
                            var title = query(badge).children('h1')[0];
                            var seats = query(badge).query('span.seats')[0];

                            if (! (title.innerHTML in counts)) {
                                counts[title.innerHTML] = 0;
                            }

                            var left = parseInt(DomAttr.get(seats, 'data-initial')) - counts[title.innerHTML];
                            updateSeats(badge, seats, left);
                        });

                        // if we have a total and no full classes, let us check out
                        if (0 < total && 0 == query('#badges .badge.full').length) {
                            btnCheckout.set('disabled', false);
                        } else {
                            btnCheckout.set('disabled', true);
                        }
                    });
                }
                registration.refresh();

                // setup a dnd source on the scout list and the badges
                window.scoutsDrop = new ScoutsDrop('scouts-list', {registration:registration});
                window.badgesDrop = {};
                query('#badges .badge').forEach(function (badge) {
                    // find the title, image and the unordered list
                    var h1 = query(badge).children('h1')[0];
                    var img = query(badge).children('img')[0];
                    var ul = query(badge).children('ul')[0];
                    var price = query(badge).query('span.price')[0].innerHTML;

                    // put a drop on the registrants list
                    var ulDrop = new RegistrantsDrop(ul, {registration:registration, badge:h1.innerHTML, price:price});
                    window.badgesDrop[h1.innerHTML] = ulDrop;

                    // put a drop on the image, such that drops onto it bounce onto list
                    var imgDrop = new BadgeDrop(img, {proxyTo:ulDrop, badge:h1.innerHTML, price:price});
                });

                // format numbers
                query('span.price').forEach(function (span) {
                    Html.set(span, priceFmt(span.innerHTML));
                });

                // connect clicks on bio info to dialogs
                query('span.action.dialog').forEach(function (span) {
                    On(span, 'click', function (ev) {
                        window[span.id + 'Dialog'].show();
                    });
                });

                // kill the overlay
                overlay.hide();

                // when showing the save for later dialog
                var origTitle = window.document.title;
                On(saveForLater, 'show', function () {
                    // get the URL that has the info saved in the query string
                    var url = save();

                    // and the date time
                    var date = Locale.format(new Date(), { formatLength:'short' });
                    var title = 'My Merit Badge Madness Registration (saved at ' + date + ')';

                    // bookmark it when possible
                    if ('sidebar' in window && 'addPanel' in window.sidebar) { // Mozilla Firefox Bookmark < v23
                        window.sidebar.addPanel(url, title, '');
                    } else if ( /*@cc_on!@*/false) { // IE Favorite
                        window.external.AddFavorite(url, title);
                    } else { // webkit - safari/chrome
                    }

                    // also update the save link, so if we need to click it/drag it, we can
                    query('.saveLink').forEach(function (a) {
                        a.href = url;
                        Html.set(a, title);
                    });
                    window.document.title = title;
                });
                On(saveForLater, 'hide', function () {
                    window.document.title = origTitle;
                });

                // when showing the scouts dialog populate textarea-from-list
                // and when hiding populate list-from-textarea
                On(scouts, 'show', function () {
                    ul2ta();
                });
                On(scouts, 'hide', ta2ul);

                // watch our forms and ensure we don't let users bypass validation
                var disabler = function (isValid, form) {
                    Registry.findWidgets(form.domNode).forEach(function (widget) {
                        if ('dijit.form.Button' === widget.declaredClass && DomClass.contains(widget.domNode, 'must-validate')) {
                            widget.setDisabled(isValid ? false : true);
                        }
                    });
                }
                Registry.byClass('dijit.form.Form').forEach(function (form) {
                    On(form, 'ValidStateChange', function (isValid) { disabler(isValid, form); });
                    form.onSubmit = function (ev) { ev.preventDefault(); };
                    form.validate();
                });

                // if given a data object from query string to load a previous, populate & go to main screen
                window.wizardDone = load();
                if (window.wizardDone) {
                    ta2ul();
                    scouts_next.set('label', 'Ok');
                    scouts_next.set('iconClass', 'icon ok');
                    go();
                } else {
                    // don't let the escape key get you out of dialogs in the startup wizard
                    var originalDialogOnKey = null;
                    Aspect.around(Dialog.prototype, '_onKey', function (original) {
                        originalDialogOnKey = original;
                        return function () { }; // no-op
                    });

                    // when wizard done, you can escape and you don't need dnd instructions any more
                    On(dndInstructions, 'hide', function () {
                        Aspect.around(Dialog.prototype, '_onKey', function (original) {
                            return originalDialogOnKey;
                        });

                        window.wizardDone = true;
                        scouts_next.set('label', 'Ok');
                        scouts_next.set('iconClass', 'icon ok');
                        go();
                    });

                    // show the welcome flow
                    welcome.show();
                }
            });
        });
});
