<?php

return array (
    'service_manager' => array (
        'abstract_factories' => array (
            'Zend\Cache\Service\StorageCacheAbstractServiceFactory',
            'Zend\Log\LoggerAbstractServiceFactory',
        ),
        'aliases' => array (
            'translator' => 'MvcTranslator',
        ),
    ),

    'translator' => array (
        'locale' => 'en_US',
        'translation_file_patterns' => array (
            array (
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),

    'controllers' => array (
        // http://www.zfdaily.com/2012/07/getting-dependencies-into-zf2-controllers/
        'factories' => array (
            'Enroll\Html\Index' => 'Html\ControllerFactory\IndexControllerFactory',
        ),
    ),

    'view_manager' => array (
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array (
            'html/index/index' => __DIR__ . '/../view/html/index/index.phtml',
        ),
        'template_path_stack' => array (
            __DIR__ . '/../view',
        ),
        'strategies' => array (
            'ViewJsonStrategy',
        ),
    ),

    'console' => array (
        'router' => array (
            'routes' => array (
            ),
        ),
    ),

    'asset_manager' => array (
        'resolver_configs' => array (
            'paths' => array (
                __DIR__ . '/../view',
            ),
        ),
    ),

    'merchant_gateway' => array (
        'production' => array (
            'endpoint'  => '',
            'signature' => '',
            'username'  => '',
            'password'  => '',
        ),
        'sandbox' => array (
            'endpoint'  => '',
            'signature' => '',
            'username'  => '',
            'password'  => '',
        ),
    ),
);
