<?php
namespace Api\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;

class SessionController extends AbstractRestfulController {
    public function getList() {
        // hard-coded to just one event, I would otherwise be looking for the event id
        return new JsonModel(
            array (
                array ('sessionId' => 1, 'title' => 'Archery', 'times' => '9am-12pm, 1pm-3pm'),
                array ('sessionId' => 2, 'title' => 'Camping', 'times' => '9am-12pm, 1pm-3pm'),
                array ('sessionId' => 3, 'title' => 'Citizenship in the World', 'times' => '9am-12pm, 1pm-3pm'),
                array ('sessionId' => 4, 'title' => 'Dentistry', 'times' => '9am-12pm, 1pm-3pm'),
                array ('sessionId' => 5, 'title' => 'First Aid', 'times' => '9am-12pm, 1pm-3pm'),
                array ('sessionId' => 6, 'title' => 'Inventing', 'times' => '9am-12pm, 1pm-3pm'),
                array ('sessionId' => 7, 'title' => 'Orienteering', 'times' => '9am-12pm, 1pm-3pm'),
                array ('sessionId' => 8, 'title' => 'Personal Management', 'times' => '9am-12pm, 1pm-3pm'),
                array ('sessionId' => 9, 'title' => 'Photography', 'times' => '9am-12pm, 1pm-3pm'),
                array ('sessionId' => 10, 'title' => 'Pulp and Paper', 'times' => '9am-12pm, 1pm-3pm'),
            )
        );
    }
 
    public function get($id) {
        # code...
    }
 
    public function create($data) {
        # code...
    }
 
    public function update($id, $data) {
        # code...
    }
 
    public function delete($id) {
        # code...
    }
}

?>
