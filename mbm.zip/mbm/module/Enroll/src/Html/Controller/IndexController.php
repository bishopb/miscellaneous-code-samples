<?php
namespace Html\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;
use Zend\Json\Json;
use Zend\Mail\Message;
use Zend\Mime\Mime as Mime;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part as MimePart;
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mail\Transport\SmtpOptions as SmtpOptions;

class IndexController extends AbstractActionController {
    public function __construct($mgParams) {
        $this->mgParams = $mgParams;
    }

    public function indexAction() {
        return new ViewModel(array (
            'offerings' => $this->getOfferings(),
        ));
    }

    /**
    * Get how many seats are available.
    *
    * curl -H 'Accept: application/json' http://example.com/Lms/public/seats
    */
    public function seatsAction() {
        // build model
        $seats = array ();
        foreach ($this->getOfferings() as $badge => $offering) {
            $seats[$badge] = $offering[0];
        }

        // return model
        return new JsonModel($seats);
    }

    /**
    * Show some basic reports.
    */
    public function reportAction() {
        return new ViewModel(array (
            'offerings' => $this->getOfferings(),
	    'enrollments' => $this->getEnrollments(),
        ));
    }

    /**
    * Send mail to POC or Scouts.
    */
    public function mailAction() {
        return new ViewModel(array (
            'offerings' => $this->getOfferings(),
	    'enrollments' => $this->getEnrollments(),
        ));
    }

    /**
    * Show a survey.
    */
    public function surveyAction() {
        return new ViewModel(array (
	    'sections' => array (
	    	'Registration' => array (
		   'A' => 'Online pre-registration was easy-to-use',
		   'B' => 'Check-in at event went smoothly',
		   'C' => 'My questions were answered at check-in',
		),
		'Hospitality' => array (
		   'F' => 'The food and drink selection was sufficient',
		   'G' => 'The food and drink filled up my scouts',
		),
	    	'Badges' => array (
		   'K' => 'All of my scouts got the badges they wanted',
		   'L' => 'The selection of badges was good',
		   'M' => 'The merit badge counselor was knowledgeable',
		   'N' => 'My scouts completed all requirements at the event',
		),
	    	'Facilities' => array (
		   'P' => 'The event location was easy to find',
		   'Q' => 'The facilities were comfortable',
		),
		'Overall' => array (
		   'Z' => 'The event was valuable to my scouts',
		),
	    ),
            'offerings' => $this->getOfferings(),
        ));
    }

    /**
    * Record a survey response.
    */
    public function respondAction() {
        $qty      = $this->params()->fromPost('qty', '');
        $noshow   = $this->params()->fromPost('noshow', array ());
        $q        = $this->params()->fromPost('q', array ());
        $comments = $this->params()->fromPost('comments', '');
	ksort($q);

	// record
        $fp = fopen($this->getResponsesFilepath(), 'a');
        if (false === $fp) {
            throw new \RuntimeException('Cannot open responses');
        }
        $ok = flock($fp, LOCK_EX);
        if (! $ok) {
            fclose($fp);
            throw new \RuntimeException('Cannot get exclusive lock on survey data');
        }

	// put it in
	fputcsv($fp, array ($qty, implode(',', $noshow), $comments) + $q);

        // done
        flock($fp, LOCK_UN);
        fclose($fp);
    }

    /**
    * Buy a registration.
    * curl -X POST http://example.com/Lms/public/enroll -d troop[]=388 -d troop[]=occoneechee \
        -d contact[]=bishop -d contact[]=bishop@gmail.com -d payment[]=4321 -d payment[]=0987654321 \
        -d registrations[0][0]=Salesmanship -d registrations[0][1]=jt
    */
    public function buyAction() {
        // get the submitted, required non-registration information
        $required = array (
            'troop-number', 'troop-council', 'contact-name', 'contact-email',
            'registrations',
            'card-type', 'card-name', 'card-number', 'card-expMth', 'card-expYr', 'card-cvv',
            'card-billingAddr1', 'card-city', 'card-state', 'card-zip'
        );
        $data = array ();
        foreach ($required as $field) {
            $value = $this->params()->fromPost($field, null);
            if (null == $value) {
                return new JsonModel(array ('success' => false, 'reason' => 'Missing required field: ' . $field));
            } else {
                $data[$field] = $value;
            }
        }
        $data['card-billingAddr2'] = $this->params()->fromPost('card-billingAddr2', '');

        // get the registrations, and calculate price along the way
        $data['registrations'] = Json::decode($data['registrations']);
        $data['price'] = 0.0;
        if (0 === count($data['registrations'])) {
            return new JsonModel(array ('success' => false, 'reason' => 'No registrations to process'));
        } else {
            foreach ($data['registrations'] as $i => $registration) {
                $data['registrations'][$i]->badge = strip_tags($registration->badge); // remove wbr
                if (3 === count((array)$registration)) {
                    if ($registration->price != 20) {
                        return new JsonModel(array ('success' => false, 'reason' => 'Price too low'));
                    } else {
                        $data['price'] += $registration->price;
                    }
                } else {
                    return new JsonModel(array ('success' => false, 'reason' => 'Registration garbled' . print_r($registration, true)));
                }
            }
        }

        // get a lock on the data file
        $fp = $this->getDataFilePointer('a+');
        $ok = flock($fp, LOCK_EX);
        if (! $ok) {
            fclose($fp);
            throw new \RuntimeException('Cannot get exclusive lock on enrollment data');
        }

        // ensure we don't go negative with any of these registrations
        fseek($fp, 0, SEEK_SET);
        foreach ($this->getOfferingsFromFP($fp) as $badge => $offering) {
            $count = $offering[0];
            foreach ($data['registrations'] as $registration) {
                if ($registration->badge === $badge) {
                    $count--;
                    if ($count < 0) {
                        flock($fp, LOCK_UN);
                        fclose($fp);
                        return new JsonModel(array ('success' => false, 'reason' => 'Class full'));
                    }
                }
            }
        }
        fseek($fp, 0, SEEK_END); // to the end in preparation for appending

        // get the ip address (need for charge)
        $remote = new \Zend\Http\PhpEnvironment\RemoteAddress;
        $remote->setUseProxy(true);
        $ipAddress = $remote->getIpAddress();

        // setup the environment to load our MerchantGateway code -- it is nowhere close to PSR-0 compliant
        $tmpPath = get_include_path();
        set_include_path(
            dirname(dirname(dirname(__DIR__))) . '/vendor/craniummax/MerchantGateway/' .
            PATH_SEPARATOR .
            $tmpPath
        );

        // make the purchase
        require_once('MerchantGateway.php');
        $paypal = \MerchantGateway::factory('PayPal', $this->mgParams['production']);
        $charge = $paypal->newCharge();
        $charge->setIpAddress($ipAddress);
        $charge->setCreditCard(
            $data['card-type'],
            $data['card-name'],
            $data['card-number'],
            $data['card-cvv'],
            $data['card-expMth'],
            $data['card-expYr'],
            $data['card-billingAddr1'],
            $data['card-billingAddr2'],
            $data['card-city'],
            $data['card-state'],
            $data['card-zip']
        );
        $charge->setAmount($data['price']);
        $charge->run();
        if ($charge->getResponse()->isFailure()) {
            flock($fp, LOCK_UN);
            fclose($fp);
            return new JsonModel(array ('success' => false, 'reason' => $charge->getResponse()->getMessageString()));
        } else {
            $receipt = $charge->getResponse()->getTransactionID();
        }

        // undo what we did with the merchant gateway setup, we're done with it
        set_include_path($tmpPath);

        // write it out
        $now = date('Y-m-d H:i:s');
        foreach ($data['registrations'] as $registration) {
            $row = array (
                $registration->badge, $registration->name,
                $data['troop-number'], $data['troop-council'],
                $data['contact-name'], $data['contact-email'],
                substr($data['card-number'], -4),
                $receipt,
                $now
            );
            fputcsv($fp, $row);
        }

        // email to point of contact
        $emailA = new Message();
        $emailA->
            addFrom('bishop.bettini@troop388.org', 'ASM Bishop Bettini')->
            addTo($data['contact-email'])->
            addCc('bishop.bettini@troop388.org')->
            setSubject('(KEEP THIS EMAIL) Confirmation receipt for Merit Badge Madness enrollments')->
            setBody($this->getBody($data))
        ;

        // email to registrar, include current file
        fseek($fp, 0, SEEK_SET); // to the beginning for complete read
        $attachment = new MimePart($fp);
        $attachment->type = 'text/csv';
        $attachment->disposition = Mime::DISPOSITION_ATTACHMENT;
        $attachment->encoding = Mime::ENCODING_BASE64;

        $body = new MimeMessage();
        $body->setParts(array ($attachment));

        $emailB = new Message();
        $emailB->
            addFrom('bishop.bettini@troop388.org', 'ASM Bishop Bettini')->
            addTo('bishop.bettini@troop388.org')->
            setSubject('New registration for MBM')->
            setBody($body)
        ;

        // send those emails
        $transport = new SmtpTransport();
        $options   = new SmtpOptions(array (
            'name'              => 'troop388.org',
            'host'              => 'smtp.gmail.com',
            'port'              => '465',
            'connection_class'  => 'login',
            'connection_config' => array (
                'ssl'      => 'ssl',
                'username' => 'ideacode.fallback@gmail.com',
                'password' => '@],!jC<l@X|\kNz7+as*Je\US',
            ),
        ));
        $transport->setOptions($options);
        $transport->send($emailA);
        $transport->send($emailB);

        // done with file, release it
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);

        // return model
        return new JsonModel(array ('success' => true, 'receipt' => $receipt, 'price' => $data['price']));
    }

    /* private API */
    private function getBody(array $data) {
        $table = new \Zend\Text\Table\Table(array ('decorator' => 'ascii', 'columnWidths' => array (60, 20)));
        $table->appendRow(array ('SCOUT', 'MERIT BADGE'));
        foreach ($data['registrations'] as $registration) {
            $table->appendRow(array ($registration->name, $registration->badge));
        }
        $lastFour = substr($data['card-number'], -4);
        $price = money_format('%i', $data['price']);

        return <<<EOTXT
Dear {$data['contact-name']},

These scouts from Troop {$data['troop-number']} ({$data['troop-council']} Council) are enrolled:
{$table}

The credit card ending in {$lastFour} was charged {$price}.

If you need help with your registration, email me at bishop.bettini@troop388.org

Also, you can find the latest updates online at www.troop388.org/mbm


-------------------------------------------------------------------------------
SPONSORED BY: tmppl
Looking for a way to spur Scouts to action and engage parents?
Try troop and patrol TEXT MESSAGING
www.tmppl.com/boy-scouts
-------------------------------------------------------------------------------


Sincerely,
Bishop Bettini, registrar &
The entire Merit Badge Madness Registration Team


P.S: Please remember that all sales are final. We are making arrangements (eg, food,
facilities, and supplies) based on your commitment to attend. If a particular Scout
cannot attend, you may send a substitute. That substitute should be prepared to
indicate whom he replaces.

P.P.S: You are not required to be present on the event day. However, I urge you
to escort your Scouts through check-in. If a Scout does not properly check-in, he
will not be permitted to stay.
EOTXT;
    }

    private function getEnrollments() {
        // open the file for read
        $fp = $this->getDataFilePointer('r');
        $ok = flock($fp, LOCK_SH);
        if (! $ok) {
            fclose($fp);
            throw new \RuntimeException('Cannot get shared lock on enrollment data');
        }

        // get the offerings
	$enrollments = array ();
        while (false !== ($row = fgetcsv($fp))) {
            list ($badge, $name, $troop, $council, $contactName, $contactEmail, $dateMade, $lastFour) = $row;
            $enrollments[] = $row;
        }

        // done
        flock($fp, LOCK_UN);
        fclose($fp);

        return $enrollments;
    }

    private function getOfferings() {
        // open the file for read
        $fp = $this->getDataFilePointer('r');
        $ok = flock($fp, LOCK_SH);
        if (! $ok) {
            fclose($fp);
            throw new \RuntimeException('Cannot get shared lock on enrollment data');
        }

        // get the offerings
        $offerings = $this->getOfferingsFromFP($fp);

        // done
        flock($fp, LOCK_UN);
        fclose($fp);

        return $offerings;
    }

    private function getOfferingsFromFP($fp) {
        // initial offerings
        // badge => seats open, price, description of price (can be null), instructor, instructor bio (can be nul)
        $initial = array (
            'Citizenship in the Community' => array (10, 20, null, 'Steven Lisowe', 'Email: <a href="mailto:stevelisowe@gmail.com">stevelisowe@gmail.com</a>', 'Citizenship in the Commun<wbr />ity', ),
            'Citizenship in the Nation' => array (10, 20, null, 'Nancy Torborg', 'Phone: 919-745-7807<br />Email: <a href="mailto:ntorborg@mac.com">ntorborg@mac.com</a>', null,),
            'Communication' => array (10, 20, null, 'Charles Lanier', 'Phone: 919-803-8977<br />Email: <a href="mailto:zedlanier@gmail.com">zedlanier@gmail.com</a>', 'Commun<wbr />ication'),
            'Cooking' => array (11, 20, null, 'Mark Carroll', 'Phone: 919-671-7251<br />Email: <a href="mailto:achefskitchen@embarqmail.com">achefskitchen@embarqmail.com</a><br /><br />
Mark is a corporate/industrial chef. He is responsible for<br />
managing a kitchen staff that prepares meals for hundreds of people<br />
every day. His skills, experience and sense of humor will make this<br />
a special Cooking Merit Badge class.', null,),
            'Leatherwork' => array (10, 20, null, 'Jerry Jester', 'Phone: 919-271-6908<br />Email: <a href="mailto:ocscouter@gmail.com">ocscouter@gmail.com</a><br /><br />
Jerry has taught this merit badge many times and brings an expertise<br />
to the classroom that is sure to make working on this merit badge<br />
lots of fun.', null,),
            'Painting' => array (10, 20, null, 'John Farrell', 'Phone: 919-218-0611<br />Email: <a href="mailto:john@thepropguy.com">john@thepropguy.com</a><br /><br />
John is known all over the country as "the prop guy". While trained<br />
as a professional photographer, John has worked building props and sets<br />
for the advertising photography, video and film market for more than 20 years.<br />
He is a design and construction genius with a wonderful personality.<br />
This will be a fascinating class!', null,),
            'Photography' => array (10, 20, null, 'Robert "Dick" Cicone', 'Phone: 919-8125405<br />Email: <a href="mailto:rcicone@nc.rr.com">rcicone@nc.rr.com</a>', null,),
            'Public Speaking' => array (10, 20, null, 'Will Stevens', 'Phone: 919-610-9819<br />Email: <a href="mailto:stillwevens@gmail.com">stillwevens@gmail.com</a>', null,),
            'Salesmanship' => array (10, 20, null, 'Ruth Anderson', 'Phone: 919-631-2118<br />Email: <a href="mailto:rander4228@shieldrep.com">rander4228@shieldrep.com</a><br /><br />
Ruth is one of the most energetic, animated, and entertaining women you\'ll<br />
ever meet. Her passion and sincerity enable her to enjoy great success in<br />
the marketplace doing saleswork and team management for LegalShield. The Scouts<br />
in this class will approach popcorn and Christmas tree sales with new confidence.', null),
            'Safety' => array (10, 20, null, 'Gary Knight', 'Phone: 919-740-1133<br />Email: <a href="mailto:garydknight@earthlink.net">garydknight@earthlink.net</a><br /><br />
Gary retired from a career in law enforcement where he distinguished himself<br />
in the City County Bureau of Investigation. His managerial and practical<br />
experience in crime scene technology, and especially photography, gives him a<br />
unique perspective on the subject of safety. His skills as a speaker and a<br />
teacher will make this class memorable.', null,),
        );

        // now subtract enrolled seats
        while (false !== ($row = fgetcsv($fp))) {
            list ($badge, $name, $troop, $council, $contactName, $contactEmail, $dateMade, $lastFour) = $row;
            $initial[$badge][0]--;
        }

        return $initial;
    }

    private function getDataFilePointer($mode) {
        $fp = fopen($this->getDataFilepath(), $mode);
        if (false === $fp) {
            throw new \RuntimeException('Cannot open enrollments');
        }
        return $fp;
    }

    private function getDataFilepath() {
        return dirname(__FILE__) . DIRECTORY_SEPARATOR . 'enrollments.csv';
    }

    private function getResponsesFilepath() {
        return dirname(__FILE__) . DIRECTORY_SEPARATOR . 'responses.csv';
    }
}

?>
