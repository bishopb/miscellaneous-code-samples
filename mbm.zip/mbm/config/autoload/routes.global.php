<?php

/**
 * Define the application routes.
 * Recall, the application's job is to glue the modules together.
 * While a module might have its own idea about what routes should be published, the application
 * ultimately arbitrates this.  Our rule is that modules do not define published routes: the
 * application does.
 */
return array (
    'router' => array (
        'routes' => array (
            'home' => array (
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array (
                    'route'    => '/',
                    'defaults' => array (
                        'controller' => 'Core\Controller\Index',
                        'action'     => 'index',
                    ),
                ),
            ),

            'enroll' => array (
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array (
                    'route'    => '/enroll',
                    'defaults' => array (
                        'controller' => 'Enroll\Html\Index',
                        'action'     => 'index',
                    ),
                ),
            ),

            'seats' => array (
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array (
                    'route'    => '/seats',
                    'defaults' => array (
                        'controller' => 'Enroll\Html\Index',
                        'action'     => 'seats',
                    ),
                ),
            ),

            'report' => array (
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array (
                    'route'    => '/report',
                    'defaults' => array (
                        'controller' => 'Enroll\Html\Index',
                        'action'     => 'report',
                    ),
                ),
            ),

            'mail' => array (
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array (
                    'route'    => '/mail',
                    'defaults' => array (
                        'controller' => 'Enroll\Html\Index',
                        'action'     => 'mail',
                    ),
                ),
            ),

            'survey' => array (
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array (
                    'route'    => '/survey',
                    'defaults' => array (
                        'controller' => 'Enroll\Html\Index',
                        'action'     => 'survey',
                    ),
                ),
            ),

            'respond' => array (
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array (
                    'route'    => '/respond',
                    'defaults' => array (
                        'controller' => 'Enroll\Html\Index',
                        'action'     => 'respond',
                    ),
                ),
            ),

            'buy' => array (
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array (
                    'route'    => '/buy',
                    'defaults' => array (
                        'controller' => 'Enroll\Html\Index',
                        'action'     => 'buy',
                    ),
                ),
            ),
        ),
    ),
);

?>
