<?php
// stop cli-server direct requests
if (PHP_SAPI === 'cli-server' && is_file(__DIR__ . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH))) {
    return false;
}

// root to the application directory
chdir(dirname(__DIR__));

// do our work, wrapped in a function to not pollute $GLOBALS
call_user_func(function () {
    // basic error handling and autoloading are fundamental
    $sentinel = require 'initialize.php';

    // now we have a reasonable ZF2 environment, run it
    $application = Zend\Mvc\Application::init(require 'config/application.config.php');
    $application->getEventManager()->attach(Zend\Mvc\MvcEvent::EVENT_FINISH, function ($ev) use ($sentinel) {
        define($sentinel, true); // initialize.php looks for this to know all finished as expected
    });
    $application->run();
});

?>
